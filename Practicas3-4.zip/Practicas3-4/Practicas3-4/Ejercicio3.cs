﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clases;
namespace Practicas3_4
{
    public partial class Ejercicio3 : Form
    {
        public Ejercicio3()
        {
            InitializeComponent();
        }
        List<Alumno> Aprobados = new List<Alumno>();
        List<Alumno> Reprobados = new List<Alumno>();
        List<Alumno> ListAlum = new List<Alumno>();

        private void AgregarAlumno(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                string Nombre = textBox1.Text;
                double Calificacion = double.Parse(textBox2.Text);
                Alumno alumno = new Alumno();
                alumno.Nombre = Nombre;
                if (Calificacion<=10)
                {
                    alumno.Calificacion = Calificacion;
                    try
                    {
                        ListAlum.Add(alumno);
                        label5.Text = "Alumno Agregado con exito";
                        DGAlumnos.DataSource = ListAlum.ToList();
                    }
                    catch (Exception Msg)
                    {
                        MessageBox.Show(Msg.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Las calificaciones no deben se mayores a 10");
                }
                
            }
            else
            {
                MessageBox.Show("Los campos no pueden estar vacios");
            }
        }
        private void SacarAlumReprobados()
        {
            foreach (var Alumno in ListAlum)
            {
                if (Alumno.Calificacion<7)
                {
                    Reprobados.Add(Alumno);
                }
                else
                {
                    Aprobados.Add(Alumno);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SacarAlumReprobados();
            DGAprobados.DataSource = Aprobados.ToList();
            DGReprobados.DataSource = Reprobados.ToList();
        }
        private void soloNumeros(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("No se permiten letras", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // solo 1 punto decimal
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                MessageBox.Show("Solo se permite 1 punto decimal", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
            
        }
        private void soloLetras(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("No se permiten numeros", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
