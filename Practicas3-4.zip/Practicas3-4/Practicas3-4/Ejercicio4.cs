﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clases;

namespace Practicas3_4
{
    public partial class Ejercicio4 : Form
    {
        public Ejercicio4()
        {
            InitializeComponent();
        }
        List<Productos> productos = new List<Productos>();
        double CompraTotal = 0;

        private void Agregar_Click(object sender, EventArgs e)
        {
            string Nombre = textBox3.Text;
            int Clave = int.Parse(textBox1.Text);
            double Precio = double.Parse(textBox2.Text);
            if (textBox1.Text != "" && textBox2.Text != "" && Nombre != "")
            {
                Productos Producto = new Productos();
                Producto.Nombre = Nombre;
                Producto.Clave = Clave;
                Producto.Precio = Precio;
                CompraTotal += Precio;
                productos.Add(Producto);
                Total.Text = $"${CompraTotal}";
            }
            else
            {
                MessageBox.Show("Los campos no pueden estar vacios");
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            DGProductos.DataSource = productos.OrderBy(prod => prod.Nombre).ToList();
        }
        private void soloNumeros(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("No se permiten letras", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // solo 1 punto decimal
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                MessageBox.Show("Solo se permite 1 punto decimal", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }

        }

        private void sinDecimal(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("No se permiten letras", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                int Clave = int.Parse(textBox1.Text);
                productos.RemoveAll(producto =>
                {
                    if (producto.Clave.Equals(Clave))
                    {
                        CompraTotal -= producto.Precio;
                        return true;
                    }
                    else
                    {
                        return false;

                    }
                }
                );
                Total.Text = $"${CompraTotal}";
                textBox1.Text = "";
                DGProductos.DataSource = productos.OrderBy(prod => prod.Nombre).ToList();
            }
            else
            {
                MessageBox.Show("Campo vacio");
            }
        }
        private void soloLetras(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("No se permiten numeros", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
