﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clases
{
    public class Productos
    {
        public string Nombre { get; set; }
        public int Clave { get; set; }
        public double Precio { get; set; }
    }
}
