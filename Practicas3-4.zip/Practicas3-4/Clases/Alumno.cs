﻿using System;
using System.Collections.Generic;

namespace Clases
{
    public class Alumno
    {
        public string Nombre { get; set; }
        public double Calificacion { get; set; }

       
    }
}
